"""
Training utilities: two-stage transfer learning (pre-train on binary alloys,
fine-tune on Sb-X target compounds) with LOEO / LOOCV evaluation.

Hyper-parameters follow the paper:
  pre-train : AdamW lr=1e-3, weight_decay=1e-5, batch=128, 60 epochs
  fine-tune : differential lr (GNN=1e-4, physics/fusion=1e-3), batch=32,
              StepLR(step=15, gamma=0.95), early-stop patience=10,
              grad-clip max_norm=1.0, MSELoss, 50 epochs, dropout=0.3
"""
import copy
import numpy as np
import torch
import torch.nn as nn
from torch.utils.data import DataLoader

from .models.dual_branch import DualBranchGNN
from .data.graph_dataset import CrystalDataset, collate_fn

DEVICE = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
SEED = 42


def set_seed(seed=SEED):
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False


def build_model(mode='dual', gnn_hidden=64, dropout=0.3):
    return DualBranchGNN(
        gnn_hidden=gnn_hidden, gnn_conv=3, gnn_n_h=1,
        phys_hidden=64, phys_layers=2, fusion_hidden=64,
        dropout=dropout, mode=mode,
    ).to(DEVICE)


def _to_device(batch):
    return {
        'atom_fea': batch['atom_fea'].to(DEVICE),
        'nbr_fea': batch['nbr_fea'].to(DEVICE),
        'nbr_fea_idx': batch['nbr_fea_idx'].to(DEVICE),
        'crystal_atom_idx': [i.to(DEVICE) for i in batch['crystal_atom_idx']],
        'phys_fea': batch['phys_fea'].to(DEVICE),
        'target': batch['target'].to(DEVICE),
    }


def train_one_epoch(model, loader, optimizer, criterion):
    model.train()
    total, n = 0.0, 0
    for batch in loader:
        b = _to_device(batch)
        optimizer.zero_grad()
        pred = model(b['atom_fea'], b['nbr_fea'], b['nbr_fea_idx'],
                     b['crystal_atom_idx'], b['phys_fea'])
        loss = criterion(pred, b['target'])
        loss.backward()
        nn.utils.clip_grad_norm_(model.parameters(), max_norm=1.0)
        optimizer.step()
        total += loss.item() * len(b['target'])
        n += len(b['target'])
    return total / max(n, 1)


@torch.no_grad()
def evaluate(model, loader):
    model.eval()
    preds, targets = [], []
    for batch in loader:
        b = _to_device(batch)
        pred = model(b['atom_fea'], b['nbr_fea'], b['nbr_fea_idx'],
                     b['crystal_atom_idx'], b['phys_fea'])
        preds.append(pred.cpu().numpy())
        targets.append(b['target'].cpu().numpy())
    preds = np.concatenate(preds)
    targets = np.concatenate(targets)
    mae = float(np.mean(np.abs(preds - targets)))
    rmse = float(np.sqrt(np.mean((preds - targets) ** 2)))
    ss_res = float(np.sum((targets - preds) ** 2))
    ss_tot = float(np.sum((targets - np.mean(targets)) ** 2))
    r2 = 1 - ss_res / ss_tot if ss_tot > 0 else 0.0
    return {'mae': mae, 'rmse': rmse, 'r2': r2, 'preds': preds, 'targets': targets}


def pretrain(source_graphs, mode='dual', epochs=60, lr=1e-3, weight_decay=1e-5,
             batch_size=128, verbose=True):
    """Stage 1: pre-train on the large binary-alloy source domain."""
    set_seed(SEED)
    model = build_model(mode=mode)
    n_params = sum(p.numel() for p in model.parameters() if p.requires_grad)
    if verbose:
        print(f"[pretrain] mode={mode}, n={len(source_graphs)}, params={n_params:,}")
    loader = DataLoader(CrystalDataset(source_graphs), batch_size=batch_size,
                        shuffle=True, collate_fn=collate_fn, drop_last=True)
    optimizer = torch.optim.AdamW(model.parameters(), lr=lr, weight_decay=weight_decay)
    criterion = nn.MSELoss()
    for ep in range(epochs):
        loss = train_one_epoch(model, loader, optimizer, criterion)
        if verbose and (ep + 1) % 10 == 0:
            print(f"  epoch {ep+1}/{epochs}  train_mse={loss:.5f}")
    return model


def finetune(target_train_graphs, target_val_graphs=None, mode='dual',
             pretrained_state=None, epochs=50, batch_size=32,
             lr_gnn=1e-4, lr_other=1e-3, weight_decay=1e-5,
             patience=10, verbose=True):
    """
    Stage 2: fine-tune on Sb-X target compounds with differential learning rates.
    Loads optional pretrained_state_dict. Returns (model, history).
    """
    set_seed(SEED)
    model = build_model(mode=mode)
    if pretrained_state is not None:
        model.load_state_dict(copy.deepcopy(pretrained_state))

    param_groups = []
    if model.gnn_branch is not None:
        param_groups.append({'params': model.gnn_branch.parameters(), 'lr': lr_gnn})
    if model.physics_branch is not None:
        param_groups.append({'params': model.physics_branch.parameters(), 'lr': lr_other})
    param_groups.append({'params': model.fusion.parameters(), 'lr': lr_other})

    optimizer = torch.optim.AdamW(param_groups, weight_decay=weight_decay)
    scheduler = torch.optim.lr_scheduler.StepLR(optimizer, step_size=15, gamma=0.95)
    criterion = nn.MSELoss()

    train_loader = DataLoader(CrystalDataset(target_train_graphs), batch_size=batch_size,
                             shuffle=True, collate_fn=collate_fn, drop_last=True)
    val_loader = (DataLoader(CrystalDataset(target_val_graphs), batch_size=batch_size,
                             shuffle=False, collate_fn=collate_fn)
                  if target_val_graphs else None)

    best_loss, best_state, wait = float('inf'), None, 0
    history = {'train': [], 'val': []}
    for ep in range(epochs):
        tr = train_one_epoch(model, train_loader, optimizer, criterion)
        scheduler.step()
        history['train'].append(tr)
        if val_loader is not None:
            vm = evaluate(model, val_loader)
            history['val'].append(vm['mae'])
            if vm['mae'] < best_loss:
                best_loss, best_state, wait = vm['mae'], copy.deepcopy(model.state_dict()), 0
            else:
                wait += 1
            if verbose and (ep + 1) % 10 == 0:
                print(f"  epoch {ep+1}/{epochs}  train={tr:.5f}  val_mae={vm['mae']:.4f}  wait={wait}")
            if wait >= patience:
                if verbose:
                    print(f"  early stop at epoch {ep+1}")
                break
        else:
            history['val'].append(None)
    if best_state is not None:
        model.load_state_dict(best_state)
    return model, history
