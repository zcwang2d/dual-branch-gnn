"""
Data loading: build CrystalGraph lists from the Materials Project derived files.

Expected input directory layout:
    data_dir/
        all_compounds.csv     # columns: mp_id, E_form, element_B, c_B, + 16 descriptor cols
        structures.pkl        # dict: mp_id -> pymatgen Structure
        sb_target.csv        # rows for the Sb-X target domain (mp_id column)
"""
import os
import pickle
import pandas as pd
from .graph_dataset import CrystalDataset, build_crystal_graph
from .descriptors import FEATURE_NAMES


def load_graphs(data_dir, target_csv='sb_target.csv'):
    """
    Returns
    -------
    source_graphs : list[CrystalGraph]  binary-alloy source domain
    target_graphs : list[CrystalGraph]  Sb-X target domain
    """
    df = pd.read_csv(os.path.join(data_dir, 'all_compounds.csv'))
    with open(os.path.join(data_dir, 'structures.pkl'), 'rb') as f:
        structures = pickle.load(f)

    target_ids = set(pd.read_csv(os.path.join(data_dir, target_csv))['mp_id'])

    source_graphs, target_graphs = [], []
    failed = 0
    for _, row in df.iterrows():
        mp_id = row['mp_id']
        if mp_id not in structures:
            failed += 1
            continue
        phys = row[FEATURE_NAMES].values.astype('float32')
        cg = build_crystal_graph(
            structures[mp_id], row['E_form'], phys,
            mp_id=mp_id, el_B=row.get('element_B', None),
            radius=8.0, max_num_nbr=12,
        )
        if mp_id in target_ids:
            target_graphs.append(cg)
        else:
            source_graphs.append(cg)
    print(f"[data] source={len(source_graphs)}  target={len(target_graphs)}  failed={failed}")
    return source_graphs, target_graphs
