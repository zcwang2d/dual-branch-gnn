"""
Crystal-graph construction utilities.
Builds CGCNN-format graphs from pymatgen Structure objects, and provides
the collate function used by PyTorch DataLoader.
"""
import numpy as np
import torch
from torch.utils.data import Dataset
from .descriptors import get_element_feature_vector


class CrystalGraph:
    """Container for one crystal graph."""

    def __init__(self, mp_id, atom_fea, nbr_fea, nbr_fea_idx, target, phys_fea, el_B=None):
        self.mp_id = mp_id
        self.atom_fea = atom_fea          # (N_atoms, 8)
        self.nbr_fea = nbr_fea          # (N_atoms, M, 41)
        self.nbr_fea_idx = nbr_fea_idx   # (N_atoms, M)
        self.target = target             # float
        self.phys_fea = phys_fea         # (16,)
        self.el_B = el_B                 # dopant element symbol (for LOEO)


def build_crystal_graph(structure, target, phys_fea, mp_id='', el_B=None,
                        radius=8.0, max_num_nbr=12):
    """
    Build a CGCNN graph from a pymatgen Structure.

    Parameters
    ----------
    structure : pymatgen.core.Structure
    target : float, formation energy label (eV/atom)
    phys_fea : array of shape (16,), physical descriptor vector
    radius : float, neighbour cutoff in Angstrom
    max_num_nbr : int, maximum neighbours per site
    """
    all_neighbors = structure.get_all_neighbors(r=radius)
    atom_fea_list, nbr_fea_list, nbr_fea_idx_list = [], [], []

    for idx, site in enumerate(structure):
        atom_fea_list.append(get_element_feature_vector(site.specie.symbol))
        nbrs = sorted(all_neighbors[idx], key=lambda x: x.nn_distance)[:max_num_nbr]
        nbr_fea = np.array([n.nn_distance for n in nbrs], dtype=np.float32)
        nbr_idx = np.array([n.index for n in nbrs], dtype=np.int64)
        if len(nbrs) < max_num_nbr:
            pad = max_num_nbr - len(nbrs)
            nbr_fea = np.pad(nbr_fea, (0, pad), constant_values=radius)
            nbr_idx = np.pad(nbr_idx, (0, pad), constant_values=idx)
        nbr_fea_list.append(nbr_fea)
        nbr_fea_idx_list.append(nbr_idx)

    atom_fea = np.array(atom_fea_list, dtype=np.float32)
    nbr_fea = np.array(nbr_fea_list, dtype=np.float32)
    nbr_fea_idx = np.array(nbr_fea_idx_list, dtype=np.int64)

    gauss = np.arange(0.0, radius + 0.2, 0.2, dtype=np.float32)
    gamma = -0.5 / (0.2 ** 2)
    nbr_fea_gauss = np.exp(gamma * (nbr_fea[:, :, None] - gauss[None, None, :]) ** 2)

    return CrystalGraph(
        mp_id=mp_id,
        atom_fea=torch.from_numpy(atom_fea),
        nbr_fea=torch.from_numpy(nbr_fea_gauss),
        nbr_fea_idx=torch.from_numpy(nbr_fea_idx),
        target=float(target),
        phys_fea=torch.as_tensor(phys_fea, dtype=torch.float32),
        el_B=el_B,
    )


def collate_fn(batch):
    """Collate a list of CrystalGraph into a batch (disjoint atoms, per-graph index)."""
    atom_feas, nbr_feas, nbr_fea_idxs, crystal_atom_idx = [], [], [], []
    targets, phys_feas, el_Bs, mp_ids = [], [], [], []
    base = 0
    for cg in batch:
        n = cg.atom_fea.shape[0]
        atom_feas.append(cg.atom_fea)
        nbr_feas.append(cg.nbr_fea)
        nbr_fea_idxs.append(cg.nbr_fea_idx + base)
        crystal_atom_idx.append(torch.arange(base, base + n, dtype=torch.long))
        targets.append(cg.target)
        phys_feas.append(cg.phys_fea)
        el_Bs.append(cg.el_B)
        mp_ids.append(cg.mp_id)
        base += n
    return {
        'atom_fea': torch.cat(atom_feas, dim=0),
        'nbr_fea': torch.cat(nbr_feas, dim=0),
        'nbr_fea_idx': torch.cat(nbr_fea_idxs, dim=0),
        'crystal_atom_idx': crystal_atom_idx,
        'phys_fea': torch.stack(phys_feas, dim=0),
        'target': torch.as_tensor(targets, dtype=torch.float32),
        'el_B': el_Bs,
        'mp_id': mp_ids,
    }


class CrystalDataset(Dataset):
    def __init__(self, graphs):
        self.graphs = graphs

    def __len__(self):
        return len(self.graphs)

    def __getitem__(self, idx):
        return self.graphs[idx]
