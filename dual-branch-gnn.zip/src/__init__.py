"""Physics-informed dual-branch GNN for Sb-X formation energy prediction."""
__version__ = "1.0.0"
