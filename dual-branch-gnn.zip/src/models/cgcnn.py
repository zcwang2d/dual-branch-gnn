"""
CGCNN (Crystal Graph Convolutional Neural Network) encoder.
Reference: Xie & Grossman, Phys. Rev. Lett. 120, 145301 (2018).
"""
import torch
import torch.nn as nn


class ConvLayer(nn.Module):
    """Single CGCNN graph-convolution layer."""

    def __init__(self, atom_fea_len, nbr_fea_len):
        super().__init__()
        self.atom_fea_len = atom_fea_len
        self.nbr_fea_len = nbr_fea_len
        self.fc_full = nn.Linear(2 * atom_fea_len + nbr_fea_len, 2 * atom_fea_len)
        self.sigmoid = nn.Sigmoid()
        self.softplus1 = nn.Softplus()
        self.bn1 = nn.BatchNorm1d(2 * atom_fea_len)
        self.bn2 = nn.BatchNorm1d(atom_fea_len)
        self.softplus2 = nn.Softplus()

    def forward(self, atom_in_fea, nbr_fea, nbr_fea_idx):
        N, M = nbr_fea_idx.shape
        atom_nbr_fea = atom_in_fea[nbr_fea_idx.reshape(-1), :].reshape(N, M, self.atom_fea_len)
        total_nbr_fea = torch.cat(
            [atom_in_fea.unsqueeze(1).expand(N, M, self.atom_fea_len),
             atom_nbr_fea, nbr_fea], dim=2)
        total_gated_fea = self.fc_full(total_nbr_fea)
        total_gated_fea = self.bn1(total_gated_fea.view(-1, self.atom_fea_len * 2)).view(N, M, self.atom_fea_len * 2)
        nbr_filter, nbr_core = total_gated_fea.chunk(2, dim=2)
        nbr_filter = self.sigmoid(nbr_filter)
        nbr_core = self.softplus1(nbr_core)
        nbr_sumed = torch.sum(nbr_filter * nbr_core, dim=1)
        nbr_sumed = self.bn2(nbr_sumed)
        return self.softplus2(atom_in_fea + nbr_sumed)


class CGCNNEncoder(nn.Module):
    """CGCNN encoder: maps a crystal graph to a structural embedding."""

    def __init__(self, atom_fea_len=64, nbr_fea_len=41, n_conv=3, h_fea_len=128,
                 n_h=1, atom_fea_input_dim=8, dropout=0.3):
        super().__init__()
        self.atom_fea_len = atom_fea_len
        self.nbr_fea_len = nbr_fea_len
        self.embedding = nn.Linear(atom_fea_input_dim, atom_fea_len)
        self.convs = nn.ModuleList([ConvLayer(atom_fea_len, nbr_fea_len) for _ in range(n_conv)])
        self.conv_to_fc = nn.Linear(atom_fea_len, h_fea_len)
        self.conv_to_fc_softplus = nn.Softplus()
        self.dropout = nn.Dropout(dropout)
        if n_h > 1:
            self.fcs = nn.ModuleList([nn.Linear(h_fea_len, h_fea_len) for _ in range(n_h - 1)])
            self.softpluses = nn.ModuleList([nn.Softplus() for _ in range(n_h - 1)])
        self.n_h = n_h

    def forward(self, atom_fea, nbr_fea, nbr_fea_idx, crystal_atom_idx):
        atom_fea = self.embedding(atom_fea)
        for conv in self.convs:
            atom_fea = conv(atom_fea, nbr_fea, nbr_fea_idx)
        crystal_fea = self._pooling(atom_fea, crystal_atom_idx)
        crystal_fea = self.conv_to_fc(self.conv_to_fc_softplus(crystal_fea))
        crystal_fea = self.conv_to_fc_softplus(crystal_fea)
        crystal_fea = self.dropout(crystal_fea)
        if self.n_h > 1:
            for fc, sp in zip(self.fcs, self.softpluses):
                crystal_fea = self.dropout(sp(fc(crystal_fea)))
        return crystal_fea

    @staticmethod
    def _pooling(atom_fea, crystal_atom_idx):
        return torch.stack([atom_fea[idx].mean(dim=0) for idx in crystal_atom_idx], dim=0)


class GaussDistanceExpansion(nn.Module):
    """Gaussian radial-basis expansion of interatomic distances."""

    def __init__(self, dmin=0.0, dmax=8.0, step=0.2):
        super().__init__()
        self.filter = torch.arange(dmin, dmax + step, step, dtype=torch.float32)
        self.gamma = -0.5 / (step ** 2)
        self.n_fea = len(self.filter)

    def forward(self, distances):
        return torch.exp(self.gamma * (distances.unsqueeze(-1) - self.filter.to(distances.device)) ** 2)
