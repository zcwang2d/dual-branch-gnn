"""
Physics-informed dual-branch GNN.
Branch 1: CGCNN structural branch   -- learns structure embedding from crystal graph.
Branch 2: physics MLP branch         -- learns 16 Miedema-derived physical descriptors.
Fusion: concatenate + MLP -> formation energy.
"""
import torch
import torch.nn as nn
from .cgcnn import CGCNNEncoder


class PhysicsBranch(nn.Module):
    """MLP over the 16-dimensional physical descriptor vector."""

    def __init__(self, input_dim=16, hidden_dim=64, n_layers=2, dropout=0.3):
        super().__init__()
        layers = [nn.Linear(input_dim, hidden_dim), nn.BatchNorm1d(hidden_dim),
                  nn.ReLU(), nn.Dropout(dropout)]
        for _ in range(n_layers - 1):
            layers += [nn.Linear(hidden_dim, hidden_dim), nn.BatchNorm1d(hidden_dim),
                       nn.ReLU(), nn.Dropout(dropout)]
        self.net = nn.Sequential(*layers)
        self.out_dim = hidden_dim

    def forward(self, x):
        return self.net(x)


class DualBranchGNN(nn.Module):
    """
    mode:
        'dual'    -- structural + physics branches fused (default)
        'gnn'     -- structural branch only
        'physics' -- physics MLP branch only
    """

    def __init__(self, atom_fea_input_dim=8, nbr_fea_len=41,
                 gnn_hidden=64, gnn_conv=3, gnn_n_h=1,
                 phys_input_dim=16, phys_hidden=64, phys_layers=2,
                 fusion_hidden=64, dropout=0.3, mode='dual'):
        super().__init__()
        self.mode = mode

        if mode in ('dual', 'gnn'):
            self.gnn_branch = CGCNNEncoder(
                atom_fea_len=64, nbr_fea_len=nbr_fea_len, n_conv=gnn_conv,
                h_fea_len=gnn_hidden, n_h=gnn_n_h,
                atom_fea_input_dim=atom_fea_input_dim, dropout=dropout)
            gnn_out_dim = gnn_hidden
        else:
            self.gnn_branch = None
            gnn_out_dim = 0

        if mode in ('dual', 'physics'):
            self.physics_branch = PhysicsBranch(phys_input_dim, phys_hidden, phys_layers, dropout)
            phys_out_dim = phys_hidden
        else:
            self.physics_branch = None
            phys_out_dim = 0

        fused_dim = gnn_out_dim + phys_out_dim
        self.fusion = nn.Sequential(
            nn.Linear(fused_dim, fusion_hidden),
            nn.BatchNorm1d(fusion_hidden),
            nn.ReLU(),
            nn.Dropout(dropout),
            nn.Linear(fusion_hidden, 1),
        )

    def forward(self, atom_fea, nbr_fea, nbr_fea_idx, crystal_atom_idx, phys_fea):
        feats = []
        if self.gnn_branch is not None:
            feats.append(self.gnn_branch(atom_fea, nbr_fea, nbr_fea_idx, crystal_atom_idx))
        if self.physics_branch is not None:
            feats.append(self.physics_branch(phys_fea))
        fused = feats[0] if len(feats) == 1 else torch.cat(feats, dim=1)
        return self.fusion(fused).squeeze(-1)
