"""
Smoke test: builds tiny synthetic crystals with pymatgen, runs a forward +
backward pass for 2 epochs through the dual-branch GNN. Does NOT require the
Materials Project database or any training data.

Run:  python -m tests.test_smoke   (from the code/ root)
"""
import sys, os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import torch
import numpy as np
from pymatgen.core import Structure, Lattice

from src.models.dual_branch import DualBranchGNN
from src.data.descriptors import compute_descriptors
from src.data.graph_dataset import CrystalGraph, CrystalDataset, collate_fn, build_crystal_graph
from torch.utils.data import DataLoader


def make_synthetic_graphs(n=8):
    """Create a few cubic NaCl-like crystals of varying Sb-X compositions."""
    graphs = []
    partners = ['Al', 'Ga', 'In', 'Zn', 'Cu', 'Ag', 'Sn', 'Bi']
    rng = np.random.default_rng(0)
    lattice = Lattice.cubic(5.0)
    for i in range(n):
        X = partners[i % len(partners)]
        struct = Structure(lattice, ['Sb', X], [[0, 0, 0], [0.5, 0.5, 0.5]])
        # add a couple more sites so the graph is non-trivial
        struct.append('Sb', [0.25, 0.25, 0.25])
        struct.append(X, [0.75, 0.75, 0.75])
        cB = 0.25 + 0.5 * (i / max(n - 1, 1))
        d = compute_descriptors('Sb', X, cB)
        phys = np.array([d[k] for k in
                         ['epsilon', 'delta_chi', 'delta_m', 'delta_Tm', 'c_B',
                          'delta_I', 'delta_K', 'VEC', 'epsilon_sq', 'delta_chi_sq',
                          'delta_m_sq', 'epsilon_cB', 'delta_chi_cB', 'delta_m_cB',
                          'delta_Hmix', 'delta_Smix']], dtype=np.float32)
        target = -0.1 - 0.3 * cB + rng.normal(0, 0.02)
        graphs.append(build_crystal_graph(struct, target, phys, mp_id=f'synth-{i}',
                                          el_B=X, radius=8.0, max_num_nbr=12))
    return graphs


def main():
    print("== smoke test ==")
    graphs = make_synthetic_graphs(8)
    print(f"built {len(graphs)} synthetic crystal graphs; "
          f"atom_fea={graphs[0].atom_fea.shape}, nbr_fea={graphs[0].nbr_fea.shape}")

    loader = DataLoader(CrystalDataset(graphs), batch_size=4, shuffle=True,
                        collate_fn=collate_fn, drop_last=True)

    model = DualBranchGNN(gnn_hidden=64, gnn_conv=3, gnn_n_h=1,
                          phys_hidden=64, phys_layers=2, fusion_hidden=64,
                          dropout=0.3, mode='dual')
    n_params = sum(p.numel() for p in model.parameters())
    print(f"dual-branch params: {n_params:,}")
    # also check the single-branch variants
    for m in ('gnn', 'physics'):
        mm = DualBranchGNN(mode=m, gnn_hidden=64, dropout=0.3)
        print(f"  mode={m:8s} params={sum(p.numel() for p in mm.parameters()):,}")

    opt = torch.optim.AdamW(model.parameters(), lr=1e-3, weight_decay=1e-5)
    crit = torch.nn.MSELoss()
    model.train()
    for ep in range(2):
        losses = []
        for batch in loader:
            opt.zero_grad()
            pred = model(batch['atom_fea'], batch['nbr_fea'], batch['nbr_fea_idx'],
                         batch['crystal_atom_idx'], batch['phys_fea'])
            loss = crit(pred, batch['target'])
            loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), max_norm=1.0)
            opt.step()
            losses.append(loss.item())
        print(f"epoch {ep+1}: loss={np.mean(losses):.4f}")

    # inference
    model.eval()
    with torch.no_grad():
        batch = next(iter(loader))
        pred = model(batch['atom_fea'], batch['nbr_fea'], batch['nbr_fea_idx'],
                     batch['crystal_atom_idx'], batch['phys_fea'])
    print(f"forward output shape={tuple(pred.shape)}, values={pred.numpy().round(3)}")
    print("== smoke test PASSED ==")


if __name__ == '__main__':
    main()
