"""
End-to-end training entry point.

Examples
--------
# pre-train on the binary source domain
python scripts/train.py --data-dir /path/to/data --stage pretrain --mode dual

# fine-tune on Sb-X target domain (loads pretrained weights)
python scripts/train.py --data-dir /path/to/data --stage finetune \
    --pretrained checkpoints/pretrained_dual.pt --mode dual
"""
import argparse
import os
import sys
import json
import torch

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from src.data import load_graphs
from src.trainer import pretrain, finetune, set_seed, DEVICE, SEED


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--data-dir', required=True, help='directory with all_compounds.csv, structures.pkl, sb_target.csv')
    ap.add_argument('--stage', choices=['pretrain', 'finetune', 'both'], default='both')
    ap.add_argument('--mode', choices=['dual', 'gnn', 'physics'], default='dual')
    ap.add_argument('--epochs-pretrain', type=int, default=60)
    ap.add_argument('--epochs-finetune', type=int, default=50)
    ap.add_argument('--batch-size-pretrain', type=int, default=128)
    ap.add_argument('--batch-size-finetune', type=int, default=32)
    ap.add_argument('--lr-gnn', type=float, default=1e-4)
    ap.add_argument('--lr-other', type=float, default=1e-3)
    ap.add_argument('--out', default='checkpoints', help='output directory')
    args = ap.parse_args()

    os.makedirs(args.out, exist_ok=True)
    set_seed(SEED)
    print(f"device={DEVICE}  mode={args.mode}")

    source_graphs, target_graphs = load_graphs(args.data_dir)

    state = None
    if args.stage in ('pretrain', 'both'):
        model = pretrain(source_graphs, mode=args.mode, epochs=args.epochs_pretrain,
                         batch_size=args.batch_size_pretrain)
        state = model.state_dict()
        p = os.path.join(args.out, f'pretrained_{args.mode}.pt')
        torch.save(state, p)
        print(f"saved {p}")

    if args.stage in ('finetune', 'both'):
        # split target into 90/10 train/val for the fine-tuning curve
        n_val = max(1, len(target_graphs) // 10)
        val = target_graphs[:n_val]
        tr = target_graphs[n_val:]
        model, history = finetune(tr, target_val_graphs=val, mode=args.mode,
                                   pretrained_state=state, epochs=args.epochs_finetune,
                                   batch_size=args.batch_size_finetune,
                                   lr_gnn=args.lr_gnn, lr_other=args.lr_other)
        p = os.path.join(args.out, f'finetuned_{args.mode}.pt')
        torch.save(model.state_dict(), p)
        with open(os.path.join(args.out, f'finetune_history_{args.mode}.json'), 'w') as f:
            json.dump(history, f, indent=2)
        print(f"saved {p}")


if __name__ == '__main__':
    main()
